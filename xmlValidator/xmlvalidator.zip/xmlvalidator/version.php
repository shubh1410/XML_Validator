<?php


/**
 * xmlvalidator question type version information.
 *
 * @package    qtype
 * @subpackage xmlvalidator
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'qtype_xmlvalidator';
$plugin->version   = 2019061700;

$plugin->requires  = 2012061700;

//$plugin->maturity  = MATURITY_BETA;
