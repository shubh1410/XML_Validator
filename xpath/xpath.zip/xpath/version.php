<?php


/**
 * xpath question type version information.
 *
 * @package    qtype
 * @subpackage xpath
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'qtype_xpath';
$plugin->version   = 2019061700;

$plugin->requires  = 2012061700;

//$plugin->maturity  = MATURITY_BETA;
