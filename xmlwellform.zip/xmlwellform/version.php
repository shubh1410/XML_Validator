<?php


/**
 * xmlwellform question type version information.
 *
 * @package    qtype
 * @subpackage xmlwellform
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'qtype_xmlwellform';
$plugin->version   = 2019061700;

$plugin->requires  = 2012061700;

//$plugin->maturity  = MATURITY_BETA;
