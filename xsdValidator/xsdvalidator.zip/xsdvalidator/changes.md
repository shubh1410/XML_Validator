# Change log for the Pattern match with JME question type


## Changes in 1.4

* Fix automated tests to pass in Moodle 3.6.


## Changes in 1.3

* Privacy API implementation.
* Update to use the newer editor_ousupsub, instead of editor_supsub.
* Fix some coding style.
* Due to privacy API support, this version now only works in Moodle 3.4+
  For older Moodles, you will need to use a previous version of this plugin.


## 1.2 and before

Changes were not documented.
